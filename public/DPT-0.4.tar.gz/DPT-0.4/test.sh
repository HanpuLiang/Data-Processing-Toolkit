echo $SHELL
