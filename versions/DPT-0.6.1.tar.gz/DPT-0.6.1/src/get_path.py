
def get_path():
    path = 'software_path'
    return path
