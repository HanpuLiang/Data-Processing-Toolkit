#!/bin/bash

version=0.6.2

echo "
  *--------------*---*
  | Data         | D | 
  |   Processing | P |
  |     Toolkit  | T |
  *--------------*---*
      Version: $version
   Author: Liang Hanpu
"

#==============#
echo "===================="
echo " Installing DPT ..."

#==============#
whichPython=`which python | grep -v "no python" | grep python | wc -l`
if [ $whichPython -eq 1 ]; then
    echo "Python found at :" `which python`
fi

#==============#
usr=`whoami`
path=/home/$usr/software/DPT-$version
echo "Install DPT at $path"
rm -rf /home/$usr/software/DPT-*
mkdir -p $path

#==============#

echo "===================="
echo " Copying files, please wait ..."

cp * $path/. -rf
chmod +x $path/DPT
chmod +x $path/lib/chgsum.pl
chmod +x $path/lib/bader
sed -i "s|software_path|$path|g" $path/src/get_path.py

rm /home/$usr/bin/DPT -f
ln -s $path/DPT /home/$usr/bin/DPT



#=============#

echo "====================
 DPT is installed successfully!
====================
 You can check DPT by \"DPT -h\"
====================
 Enjoy DPT!
"
