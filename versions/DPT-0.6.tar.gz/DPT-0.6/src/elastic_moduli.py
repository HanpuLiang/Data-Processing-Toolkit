import numpy as np 
import os
import system_cmd

def get_elastic_moduli_tensor(file_name='OUTCAR'):
    # em_ct = os.popen("grep 'TOTAL ELASTIC MODULI' OUTCAR -A 7").readlines()[3:]
    with open(file_name, 'r') as obj:
        outcar = obj.readlines()
    for i, line in enumerate(outcar):
        if 'TOTAL ELASTIC MODULI' in line:
            em_ct = outcar[i+3:i+9]
    tensor = np.array([[float(item) for item in line.split()[1:]] for line in em_ct])
    return tensor

def convert_standard(tensor):
    tensor = np.concatenate((tensor[:,0:3], tensor[:,4:6],np.array([tensor[:,3]]).T), axis=1)
    tensor = np.concatenate((tensor[0:3,:], tensor[4:6,:],np.array([tensor[3,:]])), axis=0)/10
    return tensor

def mechanically_stable(tensor):
    E = np.linalg.eigvals(tensor)
    if np.all(E>0):
        system_cmd.systemEcho(' [DPT] - This structure is mechanically stable!')
    else:
        system_cmd.systemEcho(' [DPT] * WARNING * This structure is not mechanically stable.')

def calculated_modulous(tensor):
    # intermediate parameters
    S = np.linalg.inv(tensor)
    M = tensor[0,0]+tensor[1,1]+tensor[2,2]
    N = tensor[0,1]+tensor[1,2]+tensor[2,0]
    L = tensor[3,3]+tensor[4,4]+tensor[5,5]
    SM = S[0,0]+S[1,1]+S[2,2]
    SN = S[0,1]+S[1,2]+S[2,0]
    SL = S[3,3]+S[4,4]+S[5,5]
    # all kinds of modulous and something else
    Bv = (M+2*N)/9
    Gv = (M-N+3*L)/15
    Br = (SM+2*SN)**(-1)
    Gr = 15*(4*SM-4*SN+3*SL)**(-1)
    B = (Bv+Br)/2               # bulk modulus
    G = (Gv+Gr)/2               # shear modulus
    k = G/B
    Hv = 2*(k**2*G)**(0.585)-3    # hardness
    E = 9*B*G/(3*B+G)           # Young's modulus
    v = (3*B-2*G)/(2*(3*B+G))   # Possion's ratio
    return [B, G, Hv, E, v]

def save_quantities(elastic_tensor, modulous):
    str_elastic_tensor = '\n'.join(['{0:^20.6f}{1:^20.6f}{2:^20.6f}{3:^20.6f}{4:^20.6f}{5:^20.6f}'.format(line[0],line[1],line[2],line[3],line[4],line[5]) for line in elastic_tensor])
    str_modulous = '{0:^20.6f}{1:^20.6f}{2:^20.6f}{3:^20.6f}{4:^20.6f}'.format(modulous[0],modulous[1],modulous[2],modulous[3],modulous[4])
    
    system_cmd.systemEcho(' [DPT] - Elastic Constant C_ij (unit GPa)')
    system_cmd.systemEcho(str_elastic_tensor)
    head_line = '{0:^20s}{1:^20s}{2:^20s}{3:^20s}{4:^20s}'.format('B', 'G', 'Hv', 'E', 'v')
    system_cmd.systemEcho(head_line)
    system_cmd.systemEcho(str_modulous)
    save_file(str_elastic_tensor, 'DPT.elastic_constant.dat')
    save_file(head_line+'\n'+str_modulous, 'DPT.modulous.dat')
    system_cmd.systemEcho(' [DPT] Files DPT.elastic_constant.dat and DPT.modulous.dat have been created!')

def save_file(out_str, file_name):
    with open(file_name, 'w') as obj:
        obj.write(out_str)


def elastic_moduli():
    # get elastic tensor
    elastic_tensor = get_elastic_moduli_tensor()
    # change to standard form
    elastic_tensor = convert_standard(elastic_tensor)
    # make sure the mechanically stable
    mechanically_stable(elastic_tensor)
    # all kinds of modulous and something else
    modulous = calculated_modulous(elastic_tensor)
    # save all quantities
    save_quantities(elastic_tensor, modulous)
