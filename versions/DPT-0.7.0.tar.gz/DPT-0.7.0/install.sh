#!/bin/bash

version=0.7.0

echo "
  *--------------*---*
  | Data         | D | 
  |   Processing | P |
  |     Toolkit  | T |
  *--------------*---*
      Version: $version
   Author: Liang Hanpu
"

#==============#
echo "===================="
echo " Installing DPT ..."

#==============#
whichPython=`which python | grep -v "no python" | grep python | wc -l`
if [ $whichPython -eq 1 ]; then
    echo "Python found at :" `which python`
fi

#==============#

echo "===================="

usr=`whoami`
BIN=/home/$usr/bin
path=`pwd`
chmod +x ./DPT
chmod +x ./lib/chgsum.pl
chmod +x ./lib/bader
sed -i "s|software_path|$path|g" ./src/get_path.py

rm $BIN/DPT -f
ln -s $path/DPT $BIN/DPT



#=============#

echo "====================
 DPT is installed successfully!
====================
 You can check DPT by \"DPT -h\"
====================
 Enjoy DPT!
"
