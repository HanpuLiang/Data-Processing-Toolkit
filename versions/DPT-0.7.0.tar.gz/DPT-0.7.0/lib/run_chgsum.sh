path=$1
$path/lib/chgsum.pl AECCAR0 AECCAR2
